
public class rental {

	String namapenyewa;
	String mobil;
	String durasi;
	String tanggal;
	String harga;
	@Override
	public String toString() {
		return "rental [namapenyewa=" + namapenyewa + ", mobil=" + mobil + ", durasi=" + durasi + ", tanggal=" + tanggal
				+ ", harga=" + harga + "]";
	}
	public rental(String namapenyewa, String mobil, String durasi, String tanggal, String harga) {
		super();
		this.namapenyewa = namapenyewa;
		this.mobil = mobil;
		this.durasi = durasi;
		this.tanggal = tanggal;
		this.harga = harga;
	}
	public String getNamapenyewa() {
		return namapenyewa;
	}
	public void setNamapenyewa(String namapenyewa) {
		this.namapenyewa = namapenyewa;
	}
	public String getMobil() {
		return mobil;
	}
	public void setMobil(String mobil) {
		this.mobil = mobil;
	}
	public String getDurasi() {
		return durasi;
	}
	public void setDurasi(String durasi) {
		this.durasi = durasi;
	}
	public String getTanggal() {
		return tanggal;
	}
	public void setTanggal(String tanggal) {
		this.tanggal = tanggal;
	}
	public String getHarga() {
		return harga;
	}
	public void setHarga(String harga) {
		this.harga = harga;
	}
	
	
}

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.JComboBox;
import java.awt.Color;
import java.awt.SystemColor;
import java.util.ArrayList;

import javax.swing.UIManager;
import javax.swing.JFormattedTextField;
import javax.swing.JTextField;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;

public class rentalmobil {

	private JFrame frame;
	private JTextField nama;
	private JTextField ts;
	private JTable tabel;
	private DefaultTableModel box;
	int harga;
	int hargamerk;
	int hargas;
	
	
	
	ArrayList<rental>rentals = new ArrayList<rental>();


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					rentalmobil window = new rentalmobil();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public rentalmobil() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setForeground(Color.RED);
		frame.getContentPane().setForeground(Color.PINK);
		frame.setBounds(100, 100, 724, 480);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nama Penyewa");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(10, 11, 123, 48);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Jenis Mobil");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(10, 61, 101, 41);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Durasi Penyewaan");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(10, 106, 123, 41);
		frame.getContentPane().add(lblNewLabel_2);
		
		JComboBox dp = new JComboBox();
		dp.setModel(new DefaultComboBoxModel(new String[] {"---", "1 hari", "7 hari"}));
		dp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(dp.getSelectedItem() == "---") {
                    JOptionPane.showMessageDialog(null, "Pilih durasi");
                }
                if(dp.getSelectedItem() == "1 hari") {
                    hargas=400000;
                }
                if(dp.getSelectedItem() == "7 hari") {
                    hargas=2800000;
               
                }
                
			}
			
		});
		dp.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		dp.setToolTipText("Pilih Mobil");
		dp.setEditable(true);
		dp.setBounds(209, 113, 134, 30);
		frame.getContentPane().add(dp);
		
		JComboBox jm = new JComboBox();
		jm.setFont(new Font("Tahoma", Font.PLAIN, 14));
		jm.setModel(new DefaultComboBoxModel(new String[] {"---", "Avanza", "Calya", "Agya"}));
		jm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(jm.getSelectedItem() == "---") {
                    JOptionPane.showMessageDialog(null, "Pilih Jenis Mobil yg akan disewa");
                }
                if(jm.getSelectedItem() == "Avanza") {
                    hargamerk=4;
                }
                if(jm.getSelectedItem() == "Calya") {
                    hargamerk=3;
                }
                if(jm.getSelectedItem() == "Agya") {
                    hargamerk=2;
                }
 
            }
				
			
		});
		jm.setEditable(true);
		jm.setBounds(209, 72, 134, 30);
		frame.getContentPane().add(jm);
		
		nama = new JTextField();
		nama.setBounds(209, 27, 134, 30);
		frame.getContentPane().add(nama);
		nama.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Tanggal penyewaan");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(10, 158, 161, 30);
		frame.getContentPane().add(lblNewLabel_3);
		
		ts = new JTextField();
		ts.setBounds(209, 154, 134, 31);
		frame.getContentPane().add(ts);
		ts.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(334, 244, -92, -43);
		frame.getContentPane().add(scrollPane);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(21, 212, 666, 220);
		frame.getContentPane().add(scrollPane_1);
		
		tabel = new JTable();
		tabel.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nama Penyewa", "Jenis Mobil", "Durasi Penyewaan", "Tanggal Penyewaan", "Harga"
			}
		));
		tabel.getColumnModel().getColumn(0).setPreferredWidth(92);
		tabel.getColumnModel().getColumn(3).setPreferredWidth(115);
		scrollPane_1.setViewportView(tabel);
		
		JButton input = new JButton("Input data");
		input.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String namapenyewa = nama.getText();
				String jenismobil = jm.getSelectedItem().toString();
				String durasi = dp.getSelectedItem().toString();
				String tanggal = ts.getText();
				harga = (hargamerk*hargas);
				String har = "Rp" + String.valueOf(harga);
				rentals.add(new rental(namapenyewa, jenismobil, durasi, tanggal, har));
				box = (DefaultTableModel) tabel.getModel();
				Object[] sewa = new Object[5];
				sewa[0] = namapenyewa;
				sewa[1]	= jenismobil;
				sewa[2] = durasi;
				sewa[3] = tanggal;
				sewa[4] = har;
				box.addRow(sewa);
				
			}
		});
		input.setBounds(353, 151, 143, 30);
		frame.getContentPane().add(input);
		
		JButton delete = new JButton("Delete data");
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int confirm = JOptionPane.showConfirmDialog(null, "Apakah anda ingin menghapus?", "Hapus Data", JOptionPane.YES_NO_OPTION);
                int row = tabel.getSelectedRow(); 
                if (row >= 0) {
                    if(confirm == 0) {
                        box.removeRow(row);
                        JOptionPane.showMessageDialog(null, "Data telah dihapus");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Pilih data yang ingin anda dihapus");
                }

			}
		});
		delete.setBounds(353, 106, 143, 34);
		frame.getContentPane().add(delete);
	}
}
